#define ARMA_NO_DEBUG
#include <RcppArmadillo.h>


// weighted 'one-way' within transformation
// [[Rcpp::export(name = "weighted_within_ow")]]
arma::vec weighted_within_ow(
    const arma::vec& v,
    const arma::mat& M,
    const Rcpp::IntegerVector& id,
    const Rcpp::List& ltk
) {
  // auxiliary variables (fixed)
  const int n = v.n_rows;
  const int R = M.n_rows;
  const int J = ltk.size();
  
  // auxiliary variables
  int index, j, t, T;
  arma::vec vhj(R);
  arma::vec wt(R);
  arma::vec b(R);
  arma::mat A(R, R);
  arma::vec x(n);
  
  // compute within transformation
  for (j = 0 ; j < J ; ++j) {
    // extract indexes to subset cross-sectional unit 'i'
    Rcpp::IntegerVector indexes = ltk[j];
    T = indexes.size();
    
    // compute numerator and denominator of the weighted group mean
    b.zeros();
    A.zeros();
    for (t = 0 ; t < T ; ++t) {
      index = indexes[t];
      wt = M.col(id[index]);
      b += wt * v(index);
      A += wt * wt.t();
    }
    
    // subtract weighted group means
    vhj = arma::solve(A, b);
    for (t = 0 ; t < T ; ++t) {
      index = indexes[t];
      wt = M.col(id[index]);
      x(index) = v(index) - arma::as_scalar(wt.t() * vhj);
    }
  }
  
  // return centered variable
  return x;
}


// method of alternating projections (using lambda and f as weights)
// [[Rcpp::export(name = "weighted_within_tw")]]
arma::vec weighted_within_tw(
    const arma::vec& v,
    const arma::mat& tL,
    const arma::mat& tF,
    const Rcpp::List& pids,
    const Rcpp::List& lt,
    const double tol
) {
  // auxiliary variables (fixed)
  const int n = v.n_rows;
  
  // auxiliary variables
  int iter;
  arma::vec x(n);
  arma::vec x0(n);
  
  // alternating projections
  x = v;
  for (iter = 0 ; iter < 100000 ; ++iter) {
    // check user interrupt
    Rcpp::checkUserInterrupt();
    
    // store centered vector from the last iteration
    x0 = x;
    
    // chain the two 'one-way' projections
    x = weighted_within_ow(weighted_within_ow(x, tL, pids[0], lt[1]), tF, pids[1], lt[0]);
      
    // check convergence
    if (arma::norm(x - x0, 2) < tol) break;
  }
  
  // return centered variable
  return x;
}

#define ARMA_NO_DEBUG
#include <RcppArmadillo.h>


// one-way within transformation
// [[Rcpp::export(name = "within_ow")]]
arma::vec within_ow(const arma::vec& v, const Rcpp::List& ltk) {
  // auxiliary variables (fixed)
  const int n = v.n_rows;
  const int J = ltk.size();
  
  // auxiliary variables
  double meanj;
  int index, j, t, T;
  arma::vec x(n);
  
  // compute within transformation
  for (j = 0 ; j < J ; ++j) {
    // extract indexes to subset j-th group of category 'k'
    Rcpp::IntegerVector indexes = ltk[j];
    T = indexes.size();
    
    // compute group mean
    meanj = 0.0;
    for (t = 0 ; t < T ; ++t) {
      index = indexes[t];
      meanj += v(index);
    }
    meanj /= T;
    
    // subtract group mean
    for (t = 0 ; t < T ; ++t) {
      index = indexes[t];
      x(index) = v(index) - meanj;
    }
  }
  
  // return centered variable
  return x;
}


// method of alternating projections (without weights)
// [[Rcpp::export(name = "within_tw")]]
arma::vec within_tw(const arma::vec& v, const Rcpp::List& lt, const double tol) {
  // auxiliary variables (fixed)
  const int n = v.n_rows;
  
  // auxiliary variables
  int iter;
  arma::vec x(n);
  arma::vec x0(n);
  
  // alternating projections
  x = v;
  for (iter = 0 ; iter < 100000 ; ++iter) {
    // check user interrupt
    Rcpp::checkUserInterrupt();
    
    // store centered vector from the last iteration
    x0 = x;
    
    // chain the two 'one-way' projections
    x = within_ow(within_ow(x, lt[0]), lt[1]);
    
    // check convergence
    if (arma::norm(x - x0, 2) < tol) break;
  }
  
  // return centered variable
  return x;
}

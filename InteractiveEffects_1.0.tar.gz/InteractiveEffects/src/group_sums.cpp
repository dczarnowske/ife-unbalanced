#define ARMA_NO_DEBUG
#include <RcppArmadillo.h>


// [[Rcpp::export(name = "group_sums")]]
arma::vec group_sums(const arma::vec& v, const Rcpp::List& ltk) {
  // auxiliary variables (fixed)
  const int J = ltk.size();
  
  // auxiliary variables
  int j, t, T;
  arma::vec x(J);
  x.zeros();
  
  // compute group sums
  for (j = 0 ; j < J ; ++j) {
    Rcpp::IntegerVector indexes = ltk[j];
    T = indexes.size();
    for (t = 0 ; t < T ; ++t) {
      x(j) += v(indexes[t]);
    }
  }
  
  // return vector
  return x;
}


// [[Rcpp::export(name = "truncated_group_means")]]
arma::vec truncated_group_means(
    const arma::vec& v,
    const arma::vec& w,
    const int h,
    const Rcpp::List& ltk
) {
  // auxiliary variables (fixed)
  const int J = ltk.size();
  
  // auxiliary variables
  double f;
  int g, j, t, T;
  arma::vec x(J);
  x.zeros();
  
  // compute truncated group means
  for (j = 0 ; j < J ; ++j) {
    Rcpp::IntegerVector indexes = ltk[j];
    T = indexes.size();
    for (g = 1 ; g <= h ; ++g) {
      f = 1.0 / (T - g);
      for (t = g ; t < T ; ++t) {
        x(j) += v(indexes[t]) * w(indexes[t - g]) * f;
      }
    }
  }
  
  // return vector
  return x;
}


// [[Rcpp::export(name = "truncated_weighted_group_sums")]]
arma::vec truncated_weighted_group_sums(
    const arma::vec& v,
    const arma::vec& w,
    const arma::mat& M,
    const int h,
    const Rcpp::IntegerVector& id,
    const Rcpp::List& ltk
) {
  // auxiliary variables (fixed)
  const int R = M.n_rows;
  const int J = ltk.size();
  
  // auxiliary variables
  double f, l;
  int g, j, t, T;
  arma::vec wt(R);
  arma::mat A(R, R);
  arma::mat A_inv(R, R);
  arma::vec x(J);
  x.zeros();
  
  // compute truncated (weighted) group sums
  for (j = 0 ; j < J ; ++j) {
    Rcpp::IntegerVector indexes = ltk[j];
    T = indexes.size();
    A.zeros();
    for (t = 0 ; t < T ; ++t) {
      wt = M.col(id[indexes[t]]);
      A += wt * wt.t();
    }
    A_inv = arma::inv_sympd(A);
    for (g = 1 ; g <= h ; ++g) {
      f = static_cast<double>(T) / (T - g);
      for (t = g ; t < T ; ++t) {
        l = arma::as_scalar(M.col(id[indexes[t]]).t() * A_inv * M.col(id[indexes[t - g]]));
        x(j) += l * v(indexes[t]) * w(indexes[t - g]) * f;
      }
    }
  }
  
  // return vector
  return x;
}

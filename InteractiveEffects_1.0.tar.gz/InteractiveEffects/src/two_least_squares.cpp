#define ARMA_NO_DEBUG
#include <RcppArmadillo.h>


// [[Rcpp::export(name = "two_least_squares")]]
arma::mat two_least_squares(
    const arma::mat& x,
    const arma::imat& delta,
    const arma::mat& tL
) {
  // auxiliary variables (fixed)
  const int N = x.n_rows;
  const int T = x.n_cols;
  const int R = tL.n_rows;

  // auxiliary variables
  arma::vec wt(R);
  arma::vec g(R);
  arma::mat H(R, R);

  // update common factors
  arma::mat tFt(R, T);
  for (int t = 0; t < T; ++t) {
    g.zeros();
    H.zeros();
    for (int i = 0; i < N; ++i) {
      if (delta(i, t) == 1) {
        wt = tL.col(i);
        g += wt * x(i, t);
        H += wt * wt.t();
      }
    }
    tFt.col(t) = arma::solve(H, g);
  }

  // update factor loadings
  arma::mat tLt(R, N);
  for (int i = 0; i < N; ++i) {
    g.zeros();
    H.zeros();
    for (int t = 0; t < T; ++t) {
      if (delta(i, t) == 1) {
        wt = tFt.col(t);
        g += wt * x(i, t);
        H += wt * wt.t();
      }
    }
    tLt.col(i) = arma::solve(H, g);
  }

  // return debiased matrix
  return tLt.t() * tFt;
}

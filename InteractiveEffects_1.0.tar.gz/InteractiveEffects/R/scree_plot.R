#' @title
#' Create a scree plot
#' @description
#' \code{\link{scree_plot}} is a post-estimation visualization to determine the number of factors in linear panel regression model with interactive effects providing different estimates. 
#' @param
#' fit an object of class \code{"lm_ie"}.
#' @param
#' r_max positive integer for the maximum number of factors on the horizontal axis.
#' @param
#' rescale logical. If \code{TRUE}, uses re-scaling (depending on the share of missing data) before applying the estimators. Default is \code{TRUE}. Ignored if panel is balanced.
#' @details
#' Plots the singular values against factor index. For comparison, singular values from randomly permuted data (obtained by independently shuffling each column of the demeaned outcome matrix) are added to the plot.  
#' 
#' The re-scaling before applying the estimators for unbalanced panels was suggested by Jin, Miao, and Su (2021).
#' @return
#' The function \code{\link{lm_ie}} returns a named list of class \code{"lm_ie"}.
#' @references
#' Czarnowske, D., & Stammann, A. (2020). Inference in unbalanced panel data models with interactive fixed effects. arXiv preprint arXiv:2004.03414.
#' @references
#' Dobriban, E., & Owen, A. B. (2019). Deterministic parallel analysis: an improved method for selecting factors and principal components. Journal of the Royal Statistical Society Series B: Statistical Methodology, 81(1), 163-183.
#' @references
#' Jin, S., Miao, K., & Su, L. (2021). On factor models with random missing: EM estimation, inference, and cross validation. Journal of Econometrics, 222(1), 745-777.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#'
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#'
#' # interactive fixed effects estimation with r sufficiently large
#' reg <- lm_ie(y ~ y_lag, pd, 5)
#' 
#' # generate scree plot
#' scree_plot(reg, 10)
#' }
#' @seealso
#' \code{\link{lm_ie}}
#' @export
scree_plot <- function(fit, r_max, rescale = TRUE) {
  # validity check
  if (!inherits(fit, "lm_ie")) stop("'fit' has to be of class lm_ie.", call. = FALSE)

  # extract required quantities from 'fit'
  n <- fit[["mf"]][["pdim"]][[1L]]
  t <- fit[["mf"]][["pdim"]][[2L]]
  nt <- n * t
  if (rescale) {
    scaling <- length(fit[["mf"]][["y"]])^2 / nt
  } else {
    scaling <- nt
  }
  observed <- fit[["mf"]][["observed"]]

  # compute pure factor model (impute missing values with zeros)
  if (is.null(observed)) {
    gamma <- matrix(fit[["pfm"]], n, t)
  } else {
    gamma <- matrix(0.0, n, t)
    gamma[observed] <- fit[["pfm"]]
  }

  # compute eigenvalues of the sample covariance
  if (n > t) {
    mu <- eigen(crossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  } else {
    mu <- eigen(tcrossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  }

  # parallel analysis based on Buja and Eyuboglu
  # compute quantile of eigenvalues of randomly permuted data
  np <- 199L
  epsilon <- 0.05
  rmu <- apply(sapply(seq.int(np), function(b, gamma, n, t, scaling) {
    rgamma <- apply(gamma, 2L, sample)
    if (n > t) {
      eigen(crossprod(rgamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
    } else {
      eigen(tcrossprod(rgamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
    }
  }, gamma = gamma, n = n, t = t, scaling = scaling), 1L, max)
  rmu <- rmu * (1.0 + epsilon)

  # generate scree plot
  nof <- seq.int(r_max)
  mu <- mu[nof]
  rmu <- rmu[nof]
  plot(sqrt(mu) ~ nof,
    type = "b", bty = "l", col = "#000000", lwd = 3L, pch = 17L,
    xlab = "Factor Number",
    ylab = "Singular Value"
  )
  lines(sqrt(rmu) ~ nof, col = "#009E73", lwd = 3L, pch = 19L, type = "b")

  # add a legend
  legend("topright",
    legend   = c("Sample", "Randomized"),
    col      = c("#000000", "#009E73"),
    pch      = c(17L, 19L),
    bty      = "n",
    pt.cex   = 2.0,
    cex      = 1.2,
    text.col = "black",
    horiz    = FALSE,
    inset    = c(0.1, 0.1)
  )
}

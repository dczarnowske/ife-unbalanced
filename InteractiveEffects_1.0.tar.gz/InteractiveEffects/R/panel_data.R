#' @title
#' Create panel data object
#' @description
#' \code{\link{panel_data}} creates a panel data object.
#' @param
#' data an object of class \code{"data.frame"}.
#' @param
#' xs_id name of cross-sectional identifier.
#' @param
#' time_id name of time identifier.
#' @return
#' The function \code{\link{panel_data}} returns an object of class \code{"pd_bal"} or \code{"pd_unbal"}.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # create synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#'
#' # construct panel data object
#' pd <- panel_data(df, "id", "time")
#' }
#' @export
panel_data <- function(data, xs_id, time_id) {
  # validity check for inputs
  if (!inherits(data, "data.frame")) stop("'data' has to be of class data.frame.", call. = FALSE)
  if (length(xs_id) != 1L) stop("More than one cross-sectional identifier provided.", call. = FALSE)
  if (length(time_id) != 1L) stop("More than one time identifier provided.", call. = FALSE)
  if (!(xs_id %in% names(data))) stop("Cross-sectional identifier not found in 'data'.", call. = FALSE)
  if (!(time_id %in% names(data))) stop("Time identifier not found in 'data'.", call. = FALSE)

  # transform to data.table, subset variables necessary, and order data
  pd <- as.data.table(data)
  setkeyv(pd, c(time_id, xs_id))

  # stop if any missing values
  if (any(pd[, sapply(.SD, anyNA)])) stop("'data' contains missing values.", call. = FALSE)

  # construct consecutive panel ids starting from zero
  pids <- list(
    xs_id = as.integer(factor(pd[[xs_id]])) - 1L,
    time_id = as.integer(factor(pd[[time_id]])) - 1L
  )

  # stop if data is not panel data
  nt <- nrow(pd)
  x_table <- pd[, table(mget(c(xs_id, time_id)))]
  n <- nrow(x_table)
  t <- ncol(x_table)
  observed <- as.vector(x_table)
  if (any(observed > 1L)) stop("'data' has to be panel data.", call. = FALSE)

  # generate sample size
  sample_size <- c(nt = nt, n = n, t = t)

  # generate look-up table for alternating projections
  lookup_table <- lapply(c(xs_id, time_id), function(x, indexes, data) {
    split(indexes, data[[x]])
  }, indexes = seq.int(0L, nt - 1L), data = pd)

  # generate panel data object for balanced and unbalanced
  pd_obj <- list(
    pd = pd,
    pids = pids,
    sample_size = sample_size,
    lookup_table = lookup_table
  )
  if (nt == n * t) {
    pd_obj <- structure(pd_obj, class = "pd_bal")
  } else {
    observed <- as.logical(observed)
    pd_obj <- c(pd_obj, list(observed = observed))
    pd_obj <- structure(pd_obj, class = "pd_unbal")
  }

  # return panel data object
  pd_obj
}


### generics


#' @title
#' Print \code{panel_data}
#' @description
#' \code{\link{print.pd_bal}} is a generic function which displays some minimal information from objects returned by \code{\link{panel_data}}.
#' @param
#' x an object of class \code{"pd_bal"}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{panel_data}}
#' @export
print.pd_bal <- function(x, ...) {
  cat(
    "Balanced Panel: N= ", x[["sample_size"]][[2L]], ", T= ", x[["sample_size"]][[3L]],
    ", n= ", x[["sample_size"]][[1L]], "\n",
    sep = ""
  )
}


#' @title
#' Print \code{panel_data}
#' @description
#' \code{\link{print.pd_unbal}} is a generic function which displays some minimal information from objects returned by \code{\link{panel_data}}.
#' @param
#' x an object of class \code{"pd_unbal"}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{panel_data}}
#' @export
print.pd_unbal <- function(x, ...) {
  psi <- 1.0 - x[["sample_size"]][[1L]] / (x[["sample_size"]][[2L]] * x[["sample_size"]][[3L]])
  cat(
    "Unbalanced Panel: N= ", x[["sample_size"]][[2L]], ", T= ", x[["sample_size"]][[3L]],
    ", n= ", x[["sample_size"]][[1L]], ", psi= ", formatC(round(psi, 4L)), "\n",
    sep = ""
  )
}

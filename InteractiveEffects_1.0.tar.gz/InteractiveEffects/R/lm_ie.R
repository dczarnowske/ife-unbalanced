#' @title
#' Fit linear panel regression model with interactive effects
#' @description
#' \code{\link{lm_ie}} can be used to fit linear panel regression models with interactive effects. Additional additive effects can be projected-out prior to estimation.
#' @param
#' formula an object of class \code{"formula"}: a symbolic description of the model to be fitted.
#' @param
#' data an object of class \code{"pd_bal"} or \code{"pd_unbal"} containing the variables in the model.
#' @param
#' r positive integer for the number of factors. Default is one.
#' @param
#' additive_effects additional additive effects in the model. One of \code{"none"}, \code{"gm"}, \code{"xs"}, \code{"time"}, and \code{"xs+time"}. Default is \code{"none"}, i.e., a model with no additional additive unobserved effects.
#' @param
#' beta_start optional vector of starting guesses. Default uses nuclear norm minimizing estimator to obtain starting guesses.
#' @param
#' trace non-negative integer. If positive, tracing information on the progress of the optimization is produced. Higher integers give more detail.
#' @param
#' nu non-negative tuning parameter for matrix completion procedure. If \code{nu = 0}, EM algorithm is used. If positive, debiased nuclear norm regularized algorithm is used. Default uses tuning parameter selected by \code{nu_selection}. Ignored if panel is balanced.
#' @param
#' nu_selection tuning parameter selection procedure. One of \code{"plug_in"} and \code{"cv"}. Default is \code{"plug_in"}. Ignored if panel is balanced or \code{nu} is user specified.
#' @param
#' n_iter maximum number of iterations of plug-in procedure. Default is \code{15}. Ignored if panel is balanced or \code{nu_selection = "cv"}.
#' @param
#' n_sim number of replications for the simulation within plug-in procedure. Default is \code{1000}. Ignored if panel is balanced or \code{nu_selection = "cv"}.
#' @param
#' n_trials number of trial values for the cross-validation procedure. Default is \code{30}. Ignored if panel is balanced or \code{nu_selection = "plug-in"}.
#' @param
#' n_rep number of replications for the cross-validation procedure. Default is \code{5}. Ignored if panel is balanced or \code{nu_selection = "plug-in"}.
#' @details
#' Additional additive effects can be a grand mean (\code{gm}), unit-specific effects (\code{xs}), time-specific effects (\code{time}), or unit- and time specific effects (\code{xs+time}).
#' @return
#' The function \code{\link{lm_ie}} returns a named list of class \code{"lm_ie"}.
#' @references
#' Bai, J. (2009). Panel data models with interactive fixed effects. Econometrica, 77(4), 1229-1279.
#' @references
#' Czarnowske, D., & Stammann, A. (2020). Inference in unbalanced panel data models with interactive fixed effects. arXiv preprint arXiv:2004.03414.
#' @references
#' Moon, H. R., & Weidner, M. (2015). Linear regression for panel with unknown number of factors as interactive fixed effects. Econometrica, 83(4), 1543-1579.
#' @references
#' Moon, H. R., & Weidner, M. (2018). Nuclear norm regularized estimation of panel regression models. arXiv preprint arXiv:1810.10987.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#'
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#'
#' # interactive fixed effects estimation
#' reg <- lm_ie(y ~ y_lag, pd)
#' summary(reg)
#' }
#' @export
lm_ie <- function(
  formula, data,
  r = 1L,
  additive_effects = c("none", "gm", "xs", "time", "xs+time"),
  beta_start = NULL,
  trace = 0L,
  nu = NULL,
  nu_selection = c("plug_in", "cv"),
  n_iter = 15L,
  n_sim = 1000L,
  n_trials = 30L,
  n_rep = 5L
) {
  # validity check for inputs
  if (!inherits(formula, "formula")) stop("'formula' has to be of class formula.", call. = FALSE)
  if (!inherits(data, c("pd_bal", "pd_unbal"))) stop("'data' has to be of class pd_bal or pd_unbal", call. = FALSE)
  r <- as.integer(r)
  if (r < 1L) stop("'r' has to be a strictly positive integer.", call. = FALSE)
  additive_effects <- match.arg(additive_effects)
  nu_selection <- match.arg(nu_selection)

  # construct model frame
  mf <- model_frame(formula, data, additive_effects)

  # get starting values using nnm estimator (see Moon and Weidner (2025)) if not user specified
  if (is.null(beta_start)) {
    beta_start <- starting_values(mf)
  } else {
    if (length(beta_start) != ncol(mf[["x"]])) stop("'beta_start' of wrong dimension.", call. = FALSE)
  }

  # set \nu if data is unbalanced and \nu is not user specified
  if (!is.null(mf[["observed"]]) && is.null(nu)) {
    if (nu_selection == "plug_in") {
      nu <- plugin_nu(mf, beta_start, r, n_iter, n_sim)
    } else {
      nu <- cv_nu(mf, beta_start, r, n_trials, n_rep)
    }
  } else if (!is.null(mf[["observed"]]) && !is.null(nu)) {
    nu_selection <- "user"
  } else {
    nu_selection <- "not_required"
  }

  # get least squares fit
  fit <- ls_fit(beta_start, mf, r, nu, trace)

  # compute degrees of freedom
  df <- degrees_of_freedom(mf, r, additive_effects)

  # compute r squared
  r_squared <- cor(mf[["y"]], fit[["fitted"]])

  # extend result list
  res <- c(fit, list(
    df = df,
    r_squared = r_squared,
    formula = formula,
    mf = mf,
    nu_selection = nu_selection
  ))

  # return result list
  structure(res, class = "lm_ie")
}


### generics


#' @title
#' Extract estimates of common parameters
#' @description
#' \code{\link{coef.lm_ie}} is a generic function which extracts estimates of the common parameters from objects returned by \code{\link{lm_ie}}.
#' @param
#' object an object of class \code{"lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{coef.lm_ie}} returns a named vector of estimates of the common parameters.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
coef.lm_ie <- function(object, ...) object[["coefficients"]]


#' @title
#' Extract coefficient matrix for common parameters
#' @description
#' \code{\link{coef.summary_lm_ie}} is a generic function which extracts a coefficient matrix for common parameters from objects returned by \code{\link{lm_ie}}.
#' @param
#' object an object of class \code{"summary_lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{coef.summary_lm_ie}} returns a named matrix of estimates related to the common parameters.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
coef.summary_lm_ie <- function(object, ...) object[["coefmat"]]


#' @title
#' Extract \code{lm_ie} fitted values
#' @description
#' \code{\link{fitted.lm_ie}} is a generic function which extracts fitted values from an object returned by \code{\link{lm_ie}}.
#' @param
#' object an object of class \code{"lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{fitted.lm_ie}} returns a vector of fitted values.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
fitted.lm_ie <- function(object, ...) object[["fitted"]]


#' @title
#' Print \code{lm_ie}
#' @description
#' \code{\link{print.lm_ie}} is a generic function which displays some minimal information from
#' objects returned by \code{\link{lm_ie}}.
#' @param
#' x an object of class \code{"lm_ie"}.
#' @param
#' digits unsigned integer indicating the number of decimal places. Default is \code{max(3L, getOption("digits") - 3L)}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
print.lm_ie <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("Linear Model with Interactive Fixed Effects (R=", x[["r"]], ")\n\n", sep = "")
  print(x[["coefficients"]], digits = digits)
}


#' @title
#' Print \code{summary.lm_ie}
#' @description
#' \code{\link{print.summary_lm_ie}} is a generic function which displays summary statistics from objects returned by \code{\link{summary.lm_ie}}.
#' @param
#' x an object of class \code{"summary.lm_ie"}.
#' @param
#' digits unsigned integer indicating the number of decimal places. Default is \code{max(3L, getOption("digits") - 3L)}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
print.summary_lm_ie <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("Formula:\n")
  print(x[["formula"]])
  cat("\nResiduals:\n")
  qres <- zapsmall(quantile(x[["residuals"]]), digits + 1L)
  names(qres) <- c("Min", "1Q", "Median", "3Q", "Max")
  print(qres, digits = digits, ...)
  cat("\nCoefficients:\n")
  printCoefmat(x[["coefmat"]], P.values = TRUE, has.Pvalue = TRUE, digits = digits)
  if (x[["balanced"]]) {
    cat("\nBalanced Panel:")
  } else {
    cat("\nUnbalanced Panel:")
  }
  cat(
    "\nN= ", x[["pdim"]][[1L]], ", T= ", x[["pdim"]][[2L]],
    ", n= ", x[["nobs"]], ", R= ", x[["r"]], ", df= ", x[["df"]], "\n",
    sep = ""
  )
  cat("\nMultiple R-squared:", formatC(x[["r_squared"]], digits))
  cat(
    "\nFunction value: ", formatC(x[["optim_value"]]),
    " after ", x[["optim_counts"]][[1L]], " function and ",
    x[["optim_counts"]][[2L]], " gradient calls\n",
    sep = ""
  )
}


#' @title
#' Extract \code{lm_ie} residuals
#' @description
#' \code{\link{residuals.lm_ie}} is a generic function which extracts residuals from an object returned by \code{\link{lm_ie}}.
#' @param
#' object an object of class \code{"lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{residuals.lm_ie}} returns a vector of residuals.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
residuals.lm_ie <- function(object, ...) object[["residuals"]]


#' @title
#' Summarizing models of class \code{lm_ie}
#' @description
#' Summary statistics for objects of class \code{"lm_ie"}.
#' @param
#' object an object of class \code{"lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' Returns an object of class \code{"summary.lm_ie"} which is a list of summary statistics of \code{object}.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
summary.lm_ie <- function(object, ...) {
  beta_hat <- coef(object)
  se <- sqrt(diag(vcov(object)))
  z_score <- beta_hat / se
  p_value <- 2.0 * pnorm(-abs(z_score))
  coefmat <- cbind(beta_hat, se, z_score, p_value)
  rownames(coefmat) <- names(beta_hat)
  colnames(coefmat) <- c("Estimate", "Std. error", "z value", "Pr(> |z|)")
  res <- list(
    formula = object[["formula"]],
    residuals = object[["residuals"]],
    coefmat = coefmat,
    nobs = length(object[["mf"]][["y"]]),
    df = object[["df"]],
    pdim = object[["mf"]][["pdim"]],
    r = object[["r"]],
    balanced = is.null(object[["mf"]][["observed"]]),
    r_squared = object[["r_squared"]],
    optim_value = object[["opt_info"]][["value"]],
    optim_counts = object[["opt_info"]][["counts"]]
  )
  structure(res, class = "summary_lm_ie")
}


#' @title
#' Compute covariance matrix after fitting \code{lm_ie}
#' @description
#' \code{\link{vcov.lm_ie}} estimates the covariance matrix for the estimator of the common parameters from objects returned by \code{\link{lm_ie}}.
#' @param
#' object an object of class \code{"lm_ie"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{vcov.lm_ie}} returns a named matrix of covariance estimates.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
vcov.lm_ie <- function(object, ...) {
  R <- try(chol(object[["W"]]), silent = TRUE)
  if (inherits(R, "try-error")) {
    V <- matrix(Inf, ncol(object[["W"]]), ncol(object[["W"]]))
  } else {
    fsc <- length(object[["mf"]][["y"]]) / object[["df"]]
    W_inv <- chol2inv(R)
    V <- (W_inv %*% object[["Omega"]] %*% W_inv) * fsc
  }
  V
}

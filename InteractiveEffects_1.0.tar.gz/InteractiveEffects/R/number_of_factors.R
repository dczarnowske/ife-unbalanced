#' @title
#' Estimate number of factors in linear panel regression model with interactive effects
#' @description
#' \code{\link{number_of_factors}} is a post-estimation routine to determine the number of factors in linear panel regression model with interactive effects providing different estimates. 
#' @param
#' fit an object of class \code{"lm_ie"}.
#' @param
#' rescale logical. If \code{TRUE}, uses re-scaling (depending on the share of missing data) before applying the estimators. Default is \code{TRUE}. Ignored if panel is balanced.
#' @details
#' \code{pc1}-\code{pc3}, \code{ic1}-\code{ic3}, and \code{bic3} are information criteria proposed by Bai and Ng (2002); \code{er} and \code{gr} are eigenvalue ratio tests proposed by Ahn and Horenstein (2013); \code{ed} is the edge distribution estimator of Onatski (2010); \code{pa} and \code{ddpa} are the parallel analysis and deterministic parallel analysis proposed in Dobriban and Owen (2019).  
#' 
#' \code{er} and \code{gr} and use the mock eigenvalues of Ahn and Horenstein (2013) to allow for the possibility of selecting zero factors.
#' 
#' The re-scaling before applying the estimators for unbalanced panels was suggested by Jin, Miao, and Su (2021).
#' @return
#' The function \code{\link{number_of_factors}} returns a named vector with estimates.
#' @references
#' Ahn, S. C., & Horenstein, A. R. (2013). Eigenvalue ratio test for the number of factors. Econometrica, 81(3), 1203-1227.
#' @references
#' Bai, J., & Ng, S. (2002). Determining the number of factors in approximate factor models. Econometrica, 70(1), 191-221.
#' @references
#' Czarnowske, D., & Stammann, A. (2020). Inference in unbalanced panel data models with interactive fixed effects. arXiv preprint arXiv:2004.03414.
#' @references
#' Dobriban, E., & Owen, A. B. (2019). Deterministic parallel analysis: an improved method for selecting factors and principal components. Journal of the Royal Statistical Society Series B: Statistical Methodology, 81(1), 163-183.
#' @references
#' Jin, S., Miao, K., & Su, L. (2021). On factor models with random missing: EM estimation, inference, and cross validation. Journal of Econometrics, 222(1), 745-777.
#' @references
#' Onatski, A. (2010). Determining the number of factors from empirical distribution of eigenvalues. The Review of Economics and Statistics, 92(4), 1004-1016.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#'
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#'
#' # interactive fixed effects estimation with r sufficiently large
#' reg <- lm_ie(y ~ y_lag, pd, 5)
#' 
#' # estimate number of factors
#' number_of_factors(reg)
#' }
#' @seealso
#' \code{\link{lm_ie}}
#' @export
number_of_factors <- function(fit, rescale = TRUE) {
  # validity check
  if (!inherits(fit, "lm_ie")) stop("'fit' has to be of class lm_ie.", call. = FALSE)

  # extract required quantities from 'fit'
  n <- fit[["mf"]][["pdim"]][[1L]]
  t <- fit[["mf"]][["pdim"]][[2L]]
  m <- min(n, t)
  nt <- n * t
  if (rescale) {
    scaling <- length(fit[["mf"]][["y"]])^2 / nt
  } else {
    scaling <- nt
  }
  r_max <- fit[["r"]]
  observed <- fit[["mf"]][["observed"]]

  # compute pure factor model (impute missing values with zeros)
  if (is.null(observed)) {
    gamma <- matrix(fit[["pfm"]], n, t)
  } else {
    gamma <- matrix(0.0, n, t)
    gamma[observed] <- fit[["pfm"]]
  }

  # eigenvalue and growth ratio suggested by Ahn and Horenstein (2013)
  if (n > t) {
    mu <- eigen(crossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  } else {
    mu <- eigen(tcrossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  }
  mu <- c(sum(mu[seq.int(m)]) / log(m), mu) # add mock eigenvalue
  er <- mu[seq.int(r_max + 1L)] / mu[seq.int(2L, r_max + 2L)]
  v <- sapply(seq.int(r_max + 2L), function(k, m, mu) {
    sum(mu[seq.int(k + 1L, m + 1L)])
  }, m = m, mu = mu)
  mu_tilde <- mu[seq.int(r_max + 2L)] / v
  gr <- log(1.0 + mu_tilde[seq.int(r_max + 1L)]) / log(1.0 + mu_tilde[-1L])
  ah <- c(max(which.max(er) - 1L), max(which.max(gr) - 1L))

  # information criteria suggested by Bai and NG (2002)
  sigma_sq <- sum((as.vector(gamma - principal_components(gamma, r_max)[["theta"]]))^2) / scaling
  bn <- sapply(seq.int(0L, r_max), function(r, gamma, sigma_sq, n, t, nt, m) {
    if (r > 0L) {
      u <- as.vector(gamma - principal_components(gamma, r)[["theta"]])
    } else {
      u <- as.vector(gamma)
    }
    v <- sum(u^2) / scaling
    pc1 <- v + r * sigma_sq * (n + t) / nt * log(nt / (n + t))
    pc2 <- v + r * sigma_sq * (n + t) / nt * log(m)
    pc3 <- v + r * sigma_sq * log(m) / m
    ic1 <- log(v) + r * (n + t) / nt * log(nt / (n + t))
    ic2 <- log(v) + r * (n + t) / nt * log(m)
    ic3 <- log(v) + r * log(m) / m
    bic3 <- v + r * sigma_sq * (n + t - r) * log(nt) / nt
    c(pc1, pc2, pc3, ic1, ic2, ic3, bic3)
  }, gamma = gamma, sigma_sq = sigma_sq, n = n, t = t, nt = nt, m = m)
  bn <- apply(bn, 1L, which.min) - 1L

  # edge distribution algorithm proposed by Onatski (2010)
  if (n > t) {
    mu <- eigen(crossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  } else {
    mu <- eigen(tcrossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  }
  j <- r_max + 1L
  for (iter in seq.int(5L)) {
    y <- mu[seq.int(j, j + 4L)]
    y[is.na(y)] <- 0.0
    x <- cbind(1.0, (j + seq(-1.0, 3.0))^(2.0 / 3.0))
    delta <- 2.0 * abs(coef(.lm.fit(x, y))[[2L]])
    mu_diff <- mu[seq.int(r_max)] - mu[seq.int(2L, r_max + 1L)]
    ed <- which(mu_diff >= delta)
    if (length(ed) > 0L) ed <- max(ed) else ed <- 0L
    j <- ed + 1L
  }

  # parallel analysis version of Buja and Eyuboglu (1992) (see PA in Dobriban and Owen (2019))
  np <- 199L
  epsilon <- 0.05
  if (n > t) {
    mu <- eigen(crossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  } else {
    mu <- eigen(tcrossprod(gamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
  }
  rmu <- apply(sapply(seq.int(np), function(b, gamma, n, t, scaling) {
    rgamma <- apply(gamma, 2L, sample)
    if (n > t) {
      eigen(crossprod(rgamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
    } else {
      eigen(tcrossprod(rgamma) / scaling, symmetric = TRUE, only.values = TRUE)[["values"]]
    }
  }, gamma = gamma, n = n, t = t, scaling = scaling), 1L, max)
  pa <- min(which(mu <= rmu * (1.0 + epsilon))) - 1L

  # de-randomized and deflated parallel analysis proposed by Dobriban and Owen (2019)
  ratio <- t / n
  if (n > t) {
    w <- crossprod(gamma) / scaling
  } else {
    w <- tcrossprod(gamma) / scaling
  }
  ev_lst <- eigen(w, symmetric = TRUE)
  mu <- pmax(ev_lst[["values"]], .Machine[["double.eps"]])
  v <- ev_lst[["vectors"]]
  ddpa <- 0L
  for (j in seq.int(m - 1L)) {
    epsilon <- pgd_threshold(mu, ratio)
    if (!is.finite(epsilon)) {
      ddpa <- NA_integer_
      break
    }
    if (mu[[1L]] >= epsilon) break
    ddpa <- ddpa + 1L
    w <- w - mu[[1L]] * tcrossprod(v[, 1L])
    mu <- mu[-1L]
    v <- v[, -1L, drop = FALSE]
  }

  # return estimated number of factors
  nof <- c(bn, ah, ed, pa, ddpa)
  names(nof) <- c("pc1", "pc2", "pc3", "ic1", "ic2", "ic3", "bic3", "er", "gr", "ed", "pa", "ddpa")
  nof
}

#' @title
#' Fit linear panel regression model with additive effects
#' @description
#' \code{\link{lm_fe}} can be used to fit linear panel regression models with additive effects. The estimation is based on the within transformation.
#' @param
#' formula an object of class \code{"formula"}: a symbolic description of the model to be fitted.
#' @param
#' data an object of class \code{"pd_bal"} or \code{"pd_unbal"} containing the variables in the model.
#' @param
#' additive_effects the additive effects in the model. One of \code{"xs+time"}, \code{"xs"}, and \code{"time"}. Default is \code{"xs+time"}, i.e., a model with unit- and time-specific unobserved effects.
#' @return
#' The function \code{\link{lm_fe}} returns a named list of class \code{"lm_fe"}.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#'
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#'
#' # fixed effects estimation
#' reg <- lm_fe(y ~ y_lag, pd)
#' summary(reg)
#' }
#' @export
lm_fe <- function(formula, data, additive_effects = c("xs+time", "xs", "time")) {
  # validity check for inputs
  if (!inherits(formula, "formula")) stop("'formula' has to be of class formula.", call. = FALSE)
  if (!inherits(data, c("pd_bal", "pd_unbal"))) stop("'data' has to be of class pd_bal or pd_unbal", call. = FALSE)
  additive_effects <- match.arg(additive_effects)

  # construct model frame
  mf <- model_frame(formula, data, additive_effects)

  # get least squares fit
  fit <- .lm.fit(mf[["x"]], mf[["y"]])
  beta_hat <- coef(fit)
  names(beta_hat) <- colnames(mf[["x"]])
  W <- crossprod(mf[["x"]])
  Omega <- crossprod(mf[["x"]] * residuals(fit))

  # compute degrees of freedom
  df <- degrees_of_freedom(mf, 0L, additive_effects)

  # compute r squared
  y_hat <- mf[["y"]] - residuals(fit)
  r_squared <- cor(mf[["y"]], y_hat)

  # extend result list
  res <- list(
    coefficients = beta_hat,
    fe = additive_effects,
    fitted = y_hat,
    residuals = residuals(fit),
    W = W,
    Omega = Omega,
    df = df,
    r_squared = r_squared,
    formula = formula,
    mf = mf
  )

  # return result list
  structure(res, class = "lm_fe")
}


### generics


#' @title
#' Extract estimates of common parameters
#' @description
#' \code{\link{coef.lm_fe}} is a generic function which extracts estimates of the common parameters from objects returned by \code{\link{lm_fe}}.
#' @param
#' object an object of class \code{"lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{coef.lm_fe}} returns a named vector of estimates of the common parameters.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
coef.lm_fe <- function(object, ...) object[["coefficients"]]


#' @title
#' Extract coefficient matrix for common parameters
#' @description
#' \code{\link{coef.summary_lm_fe}} is a generic function which extracts a coefficient matrix for common parameters from objects returned by \code{\link{lm_fe}}.
#' @param
#' object an object of class \code{"summary_lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{coef.summary_lm_fe}} returns a named matrix of estimates related to the common parameters.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
coef.summary_lm_fe <- function(object, ...) object[["coefmat"]]


#' @title
#' Extract \code{lm_fe} fitted values
#' @description
#' \code{\link{fitted.lm_fe}} is a generic function which extracts fitted values from an object returned by \code{\link{lm_fe}}.
#' @param
#' object an object of class \code{"lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{fitted.lm_fe}} returns a vector of fitted values.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
fitted.lm_fe <- function(object, ...) object[["fitted"]]


#' @title
#' Print \code{lm_fe}
#' @description
#' \code{\link{print.lm_fe}} is a generic function which displays some minimal information from
#' objects returned by \code{\link{lm_fe}}.
#' @param
#' x an object of class \code{"lm_fe"}.
#' @param
#' digits unsigned integer indicating the number of decimal places. Default is \code{max(3L, getOption("digits") - 3L)}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
print.lm_fe <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("Linear Model with Additive Fixed Effects (", x[["fe"]], ")\n\n", sep = "")
  print(x[["coefficients"]], digits = digits)
}


#' @title
#' Print \code{summary.lm_fe}
#' @description
#' \code{\link{print.summary_lm_fe}} is a generic function which displays summary statistics from objects returned by \code{\link{summary.lm_fe}}.
#' @param
#' x an object of class \code{"summary.lm_fe"}.
#' @param
#' digits unsigned integer indicating the number of decimal places. Default is \code{max(3L, getOption("digits") - 3L)}.
#' @param
#' ... other arguments.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
print.summary_lm_fe <- function(x, digits = max(3L, getOption("digits") - 3L), ...) {
  cat("Formula:\n")
  print(x[["formula"]])
  cat("\nResiduals:\n")
  qres <- zapsmall(quantile(x[["residuals"]]), digits + 1L)
  names(qres) <- c("Min", "1Q", "Median", "3Q", "Max")
  print(qres, digits = digits, ...)
  cat("\nCoefficients:\n")
  printCoefmat(x[["coefmat"]], P.values = TRUE, has.Pvalue = TRUE, digits = digits)
  if (x[["balanced"]]) {
    cat("\nBalanced Panel:")
  } else {
    cat("\nUnbalanced Panel:")
  }
  cat(
    "\nN= ", x[["pdim"]][[1L]], ", T= ", x[["pdim"]][[2L]],
    ", n= ", x[["nobs"]], ", fe= ", x[["fe"]], ", df= ", x[["df"]], "\n",
    sep = ""
  )
  cat("\nMultiple R-squared:", formatC(x[["r_squared"]], digits))
}


#' @title
#' Extract \code{lm_fe} residuals
#' @description
#' \code{\link{residuals.lm_fe}} is a generic function which extracts residuals from an object returned by \code{\link{lm_fe}}.
#' @param
#' object an object of class \code{"lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{residuals.lm_fe}} returns a vector of residuals.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
residuals.lm_fe <- function(object, ...) object[["residuals"]]


#' @title
#' Summarizing models of class \code{lm_fe}
#' @description
#' Summary statistics for objects of class \code{"lm_fe"}.
#' @param
#' object an object of class \code{"lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' Returns an object of class \code{"summary.lm_fe"} which is a list of summary statistics of \code{object}.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
summary.lm_fe <- function(object, ...) {
  beta_hat <- coef(object)
  se <- sqrt(diag(vcov(object)))
  z_score <- beta_hat / se
  p_value <- 2.0 * pnorm(-abs(z_score))
  coefmat <- cbind(beta_hat, se, z_score, p_value)
  rownames(coefmat) <- names(beta_hat)
  colnames(coefmat) <- c("Estimate", "Std. error", "z value", "Pr(> |z|)")
  res <- list(
    formula = object[["formula"]],
    residuals = object[["residuals"]],
    coefmat = coefmat,
    nobs = length(object[["mf"]][["y"]]),
    df = object[["df"]],
    pdim = object[["mf"]][["pdim"]],
    fe = object[["fe"]],
    balanced = is.null(object[["mf"]][["observed"]]),
    r_squared = object[["r_squared"]]
  )
  structure(res, class = "summary_lm_fe")
}


#' @title
#' Compute covariance matrix after fitting \code{lm_fe}
#' @description
#' \code{\link{vcov.lm_fe}} estimates the covariance matrix for the estimator of the common parameters from objects returned by \code{\link{lm_fe}}.
#' @param
#' object an object of class \code{"lm_fe"}.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{vcov.lm_fe}} returns a named matrix of covariance estimates.
#' @seealso
#' \code{\link{lm_fe}}
#' @export
vcov.lm_fe <- function(object, ...) {
  R <- try(chol(object[["W"]]), silent = TRUE)
  if (inherits(R, "try-error")) {
    V <- matrix(Inf, ncol(object[["W"]]), ncol(object[["W"]]))
  } else {
    fsc <- length(object[["mf"]][["y"]]) / object[["df"]]
    W_inv <- chol2inv(R)
    V <- (W_inv %*% object[["Omega"]] %*% W_inv) * fsc
  }
  V
}

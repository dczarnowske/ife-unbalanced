#' @title
#' Asymptotic bias correction for linear panel regression model
#' @description
#' \code{\link{bias_correction}} is a post-estimation routine to reduce asymptotic bias due to heteroscedasticity of the idiosyncratic error term and due to predetermined regressors.
#' @param
#' fit an object of class \code{"lm_fe"} or \code{"lm_ie"}.
#' @param
#' L non-negative integer. Bandwidth for the truncation kernel of Newey and West (1987). Positive values correct feedback bias.
#' @param
#' ... other arguments.
#' @return
#' The function \code{\link{bias_correction}} returns a named list of class \code{"lm_ie"}.
#' @references
#' Newey, W. K., & West, K. D. (1987). Hypothesis testing with efficient method of moments estimation. International Economic Review, 777-787.
#' @seealso
#' \code{\link{lm_fe}} and \code{\link{lm_ie}}
#' @export
bias_correction <- function(fit, L, ...) UseMethod("bias_correction")


### generics


#' @title
#' Asymptotic bias correction for linear panel regression model with interactive effects
#' @description
#' \code{\link{bias_correction}} is a post-estimation routine for linear panel regression model with interactive effects to reduce asymptotic bias asymptotic bias due to heteroscedasticity of the idiosyncratic error term and due to predetermined regressors (feedback bias).
#' @param
#' fit an object of class \code{"lm_ie"}.
#' @param
#' L non-negative integer. Bandwidth for the truncation kernel of Newey and West (1987). Positive values correct feedback bias. Default is zero.
#' @param
#' xs_het logical. If \code{TRUE}, corrects bias due to cross-sectional heteroscedasticity of the idiosyncratic error term. Default is \code{FALSE}.
#' @param
#' ts_het logical. If \code{TRUE}, corrects bias due to time-series heteroscedasticity of the idiosyncratic error term. Default is \code{FALSE}.
#' @param
#' update_vcov logical. If \code{TRUE}, recomputes the covariance matrix after debiasing the common parameters. Default is \code{TRUE}.
#' @param
#' ... other arguments.
#' @details
#' The asymptotic bias correction was proposed by Bai (2009) and Moon and Weidner (2017) for linear panel regression models in balanced panels. For linear panel regression models in unbalanced panels, thebias correction was proposed by Czarnowske and Stammann (2020).
#' @return
#' The function \code{\link{bias_correction}} returns a named list of class \code{"lm_ie"}.
#' @references
#' Bai, J. (2009). Panel data models with interactive fixed effects. Econometrica, 77(4), 1229-1279.
#' @references
#' Czarnowske, D., & Stammann, A. (2020). Inference in unbalanced panel data models with interactive fixed effects. arXiv preprint arXiv:2004.03414.
#' @references
#' Moon, H. R., & Weidner, M. (2017). Dynamic linear panel regression models with interactive fixed effects. Econometric Theory, 33(1), 158-195.
#' @references
#' Newey, W. K., & West, K. D. (1987). Hypothesis testing with efficient method of moments estimation. International Economic Review, 777-787.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#' 
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#' 
#' # interactive fixed effects estimation
#' reg <- lm_ie(y ~ y_lag, pd)
#' 
#' # debias estimates
#' reg_bc <- bias_correction(reg, L = 5L, xs_het = TRUE, ts_het = TRUE)
#' summary(reg_bc)
#' }
#' @seealso
#' \code{\link{lm_ie}}
#' @export
bias_correction.lm_ie <- function(fit, L = 0L, xs_het = FALSE, ts_het = FALSE, update_vcov = TRUE, ...) {
  # validity checks
  L <- as.integer(L)
  if (L < 0L) stop("'L' (bandwidth) has to be of positive.", call. = FALSE)
  if (!is.logical(xs_het)) stop("'xs_het' has to be of type logical.", call. = FALSE)
  if (!is.logical(ts_het)) stop("'ts_het' has to be of type logical.", call. = FALSE)
  if (!is.logical(update_vcov)) stop("'update_vcov' has to be of type logical.", call. = FALSE)

  # check if bias correction is necessary
  if (L == 0L && xs_het == FALSE && ts_het == FALSE) stop("No bias correction necessary.", call. = FALSE)

  # extract required quantities from 'fit'
  y <- fit[["mf"]][["y"]]
  x <- fit[["mf"]][["x"]]
  n <- fit[["mf"]][["pdim"]][[1L]]
  t <- fit[["mf"]][["pdim"]][[2L]]
  pids <- fit[["mf"]][["pids"]]
  lt <- fit[["mf"]][["lookup_table"]]
  observed <- fit[["mf"]][["observed"]]
  r <- fit[["r"]]
  beta_tilde <- coef(fit)
  e <- residuals(fit)
  f <- fit[["f"]]
  lambda <- fit[["lambda"]]
  W <- fit[["W"]]

  # compute pure factor model (impute missing values with zeros)
  theta <- tcrossprod(lambda, f)
  if (!is.null(observed)) {
    theta[!observed] <- 0.0
  }
  
  # debias least squares interactive effects estimator
  if (L > 0L) {
    xt_01 <- apply(x, MARGIN = 2L, FUN = weighted_within_ow, M = t(f), id = pids[[2L]], ltk = lt[[1L]])
    B <- colMeans(apply(xt_01, MARGIN = 2L, truncated_weighted_group_sums, w = e, M = t(f), h = L, id = pids[[2L]], ltk = lt[[1L]]))
    beta_tilde <- beta_tilde + solve(W / n, B)
  }
  if (xs_het || ts_het) {
    phi <- t(f) %*% crossprod(theta) %*% f
    xi <- as.vector(lambda %*% crossprod(f) %*% solve(phi) %*% t(f))
    if (!is.null(observed)) {
      xi <- xi[observed]
    }
    if (xs_het) {
      xt_10 <- apply(x, MARGIN = 2L, FUN = weighted_within_ow, M = t(lambda), id = pids[[1L]], ltk = lt[[2L]])
      B <- colMeans(
        apply(xt_10 * xi, MARGIN = 2L, group_sums, ltk = lt[[1L]]) * as.vector(group_sums(e^2, lt[[1L]]))
      )
      rm(xt_10)
      beta_tilde <- beta_tilde + solve(W / n, B)
    }
    if (ts_het) {
      xt_01 <- apply(x, MARGIN = 2L, FUN = weighted_within_ow, M = t(f), id = pids[[2L]], ltk = lt[[1L]])
      B <- colMeans(
        apply(xt_01 * xi, MARGIN = 2L, group_sums, ltk = lt[[2L]]) * as.vector(group_sums(e^2, lt[[2L]]))
      )
      rm(xt_01)
      beta_tilde <- beta_tilde + solve(W / t, B)
    }
  }
  fit[["coefficients"]] <- beta_tilde

  # update W and \Omega if requested
  if (update_vcov) {
    pfm <- y - as.vector(x %*% beta_tilde)
    if (is.null(observed)) {
      gamma <- matrix(pfm, n, t)
      pca <- principal_components(gamma, r)
      e <- as.vector(gamma - pca[["theta"]])
    } else {
      gamma <- matrix(0.0, n, t)
      gamma[observed] <- pfm
      gamma <- matrix_completion(gamma, r, observed, fit[["nu"]])
      pca <- principal_components(gamma, r)
      e <- as.vector(gamma - pca[["theta"]])[observed]
    }
    lambda <- pca[["lambda"]]
    f <- pca[["f"]]
    xt_11 <- apply(
      x, 2L,
      FUN = weighted_within_tw, tL = t(lambda), tF = t(f), pids = pids, lt = lt, tol = 1.0e-08
    )
    W <- crossprod(xt_11)
    Omega <- crossprod(xt_11 * e)
    fit[["W"]] <- W
    fit[["Omega"]] <- Omega
  }

  # add information about the bias correction
  fit[["bc_info"]] <- list(L = L, xs_het = xs_het, ts_het = ts_het)

  # return result list
  fit
}


#' @title
#' Asymptotic bias correction for linear panel regression model with additive effects
#' @description
#' \code{\link{bias_correction}} is a post-estimation routine for linear panel regression model with additive effects to reduce asymptotic bias due to predetermined regressors (feedback bias).
#' @param
#' fit an object of class \code{"lm_fe"}.
#' @param
#' L non-negative integer. Bandwidth for the truncation kernel of Newey and West (1987). Positive values correct feedback bias.
#' @param
#' ... other arguments.
#' @details
#' The asymptotic bias correction was proposed by Hahn and Kuersteiner (2002) for linear panel regression models with unit-specific effects. For linear panel regression models with unit- and time-specific effects, Hahn and Moon (2006) showed that the same bias correction can be applied.
#' @return
#' The function \code{\link{bias_correction}} returns a named list of class \code{"lm_fe"}.
#' @references
#' Hahn, J., & Kuersteiner, G. (2002). Asymptotically unbiased inference for a dynamic panel model with fixed effects when both n and T are large. Econometrica, 70(4), 1639-1657.
#' @references
#' Hahn, J., & Moon, H. R. (2006). Reducing bias of MLE in a dynamic panel model. Econometric Theory, 22(3), 499-512.
#' @references
#' Newey, W. K., & West, K. D. (1987). Hypothesis testing with efficient method of moments estimation. International Economic Review, 777-787.
#' @examples
#' \donttest{
#' # load package
#' library(InteractiveEffects)
#'
#' # generate synthetic data set
#' df <- synthetic_data(125, 25, 4711, psi = 0.2)
#' 
#' # create panel data object
#' pd <- panel_data(df, "id", "time")
#' 
#' # fixed effects estimation
#' reg <- lm_fe(y ~ y_lag, pd)
#' 
#' # debias estimates
#' reg_bc <- bias_correction(reg, L = 3L)
#' summary(reg_bc)
#' }
#' @seealso
#' \code{\link{lm_fe}}
#' @export
bias_correction.lm_fe <- function(fit, L = 0L, ...) {
  # validity checks
  L <- as.integer(L)
  if (L < 0L) stop("'L' (bandwidth) has to be of positive.", call. = FALSE)

  # check if bias correction is necessary
  if (L == 0L || fit[["fe"]] == "time") stop("No bias correction necessary.", call. = FALSE)

  # extract required quantities from 'fit'
  y <- fit[["mf"]][["y"]]
  x <- fit[["mf"]][["x"]]
  n <- fit[["mf"]][["pdim"]][[1L]]
  t <- fit[["mf"]][["pdim"]][[2L]]
  ltk <- fit[["mf"]][["lookup_table"]][[1L]]
  beta_tilde <- coef(fit)
  e <- residuals(fit)
  W <- fit[["W"]]

  # debias least squares fixed effects estimator
  B <- colMeans(apply(x, MARGIN = 2L, truncated_group_means, w = e, h = L, ltk = ltk))
  beta_tilde <- beta_tilde + solve(W / n, B)
  fit[["coefficients"]] <- beta_tilde

  # add information about the bias correction
  fit[["bc_info"]] <- list(L = L)

  # return result list
  fit
}

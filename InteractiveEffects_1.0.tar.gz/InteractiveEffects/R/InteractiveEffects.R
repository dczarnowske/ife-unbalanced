#' @title
#' InteractiveEffects
#' @description
#' Fits linear panel regression models with interactive fixed effects (IFE) in balanced and unbalanced panels following Bai (2009) <doi:10.3982/ECTA6135> and Czarnowske and Stammann (2020) <arXiv:2004.03414>. Unbalancedness is accommodated under conditionally random attrition. Provides bias correction procedures to account for asymptotic bias due to heteroscedasticity of the idiosyncratic error term and due to predetermined regressors, as well as routines for estimating the number of factors.
#' @name
#' InteractiveEffects-package
#' @aliases
#' InteractiveEffects-package
#' @importFrom
#' data.table as.data.table setkeyv := .SD
#' @importFrom
#' Rcpp evalCpp
#' @importFrom
#' graphics legend lines
#' @importFrom
#' softImpute complete impute lambda0 softImpute
#' @importFrom
#' stats .lm.fit coef cor model.matrix optim pnorm printCoefmat quantile 
#' residuals rnorm rt sd vcov
#' @useDynLib
#' InteractiveEffects, .registration = TRUE
NULL
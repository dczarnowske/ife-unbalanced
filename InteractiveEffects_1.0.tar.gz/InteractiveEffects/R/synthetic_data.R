#' @title
#' Generate a synthetic data set
#' @description
#' Generate a synthetic data set for an AR1 model with one factor. Adaption of the DGP in Moon and Weidner (2017) (see Czarnowske and Stammann (2020) for details).
#' @param
#' n a strictly positive integer equal to the number of cross-sectional units.
#' @param
#' t a strictly positive integer equal to the number of time periods.
#' @param
#' seed a strictly positive integer.
#' @param
#' rho process parameter. Satisfies \eqn{\rho \in (- 1, 1)}.
#' @param
#' psi share of missing observations. Satisfies \eqn{\psi \in [0, 0.5)}.
#' @return
#' The function \code{\link{synthetic_data}} returns a data.frame with five variables.
#' @seealso
#' \code{\link{lm_ie}}
#' @export
synthetic_data <- function(n, t, seed, rho = 0.9, psi = 0.0) {
  # validity checks
  n <- as.integer(n)
  if (n < 1L) stop("Number of cross-sectional units should be at least one.", call. = FALSE)
  t <- as.integer(t)
  if (t < 1L) stop("Number of time periods should be at least one.", call. = FALSE)
  seed <- as.integer(seed)
  if (seed < 0L) stop("'seed' has to be a positive integer.", call. = FALSE)
  rho <- as.double(rho)
  if (rho <= - 1.0 || rho >= 1.0) stop("'rho' has to be in (- 1, 1).", call. = FALSE)
  psi <- as.double(psi)
  if (psi < 0.0 || psi >= 0.5) stop("'psi' has to be in [0, 0.5).", call. = FALSE)
  
  # fixed parameters
  burnin <- 1000L
  rho_f <- 0.5
  sigma_f <- 0.5
  
  # panel identifiers
  id <- rep.int(seq.int(n), t)
  time <- rep(seq.int(t), each = n)
  
  # generate dependent variable
  set.seed(seed)
  lambda <- rnorm(n, 1.0, 1.0)
  f <- numeric(t + burnin + 1L)
  f[[1L]] <- rnorm(1L, 0.0, sigma_f)
  Y <- matrix(NA_real_, n, t + burnin + 1L)
  Y[, 1L] <- lambda * f[[1L]] + rt(n, 5L)
  for (s in seq.int(2L, t + burnin + 1L)) {
    f[[s]] <- rho_f * f[[s - 1L]] + rnorm(1L, 0.0, sqrt(1 - rho_f^2) * sigma_f)
    Y[, s] <- rho * Y[, s - 1L] + lambda * f[[s]] + rt(n, 5L)
  }
  Y <- Y[, - seq.int(burnin)]
  Y_lag <- Y[, - (t + 1L)]
  Y <- Y[, - 1L]
  
  # transform matrices to vectors
  y <- as.vector(Y)
  y_lag <- as.vector(Y_lag)
  lambda_long <- rep(lambda, t)
  
  # generate balanced panel data set
  df <- data.frame(id, time, y, y_lag, lambda = lambda_long)
  df <- df[order(time, lambda_long, id), ]
  
  # drop data if requested
  if (psi > 0.0) {
    # time series of type 1 individuals start randomly at (1, t2 + 1) and last for t2 periods
    alpha <- 2.0 * psi
    n1 <- floor(alpha * n)
    n2 <- n - n1
    t1 <- floor(t / 2)
    keep <- as.vector(rbind(
      t(sapply(sample.int(t1 + 1L, n1, replace = TRUE), function(x) {
        c(rep(FALSE, x - 1L), rep(TRUE, t1), rep(FALSE, t - t1 - x + 1L))
      })),
      matrix(TRUE, n2, t)
    ))
    
    # drop observations from balanced panel data set
    df <- df[keep, ]
  }
  
  # return panel data set 
  df
}

### internal functions


## general


# cross validation for soft imputation
cv_nu <- function(mf, beta_start, r_max, n_trials, n_rep) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  pfm <- mf[["y"]] - as.vector(mf[["x"]] %*% beta_start)
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- pfm
  observed <- which(observed)
  nt_obs <- length(observed)
  scaling <- sqrt((n * t) / nt_obs)
  nu_max <- lambda0(gamma)
  nu_grid <- exp(seq(
    log(nu_max * 0.99), log(nu_max * 0.001),
    length = n_trials
  )) * scaling
  cv_mse <- matrix(NA_real_, nrow = n_trials, ncol = n_rep)
  for (k in seq.int(n_rep)) {
    observed_train <- sample(observed, floor(nt_obs^2 / (n * t)))
    observed_test <- setdiff(observed, observed_train)
    gamma_train <- matrix(NA_real_, n, t)
    gamma_train[observed_train] <- gamma[observed_train]
    fit <- NULL
    for (j in seq_along(nu_grid)) {
      fit <- suppressWarnings(softImpute(
        gamma_train,
        rank.max = r_max, lambda = nu_grid[[j]],
        type = "svd", warm.start = fit
      ))
      gamma_hat <- impute(fit, row(gamma)[observed_test], col(gamma)[observed_test])
      cv_mse[j, k] <- mean((gamma[observed_test] - gamma_hat)^2)
    }
  }
  nu_grid[[which.min(rowMeans(cv_mse))]]
}


# compute degrees of freedom
degrees_of_freedom <- function(mf, r, additive_effects) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  nt_obs <- nrow(mf[["x"]])
  k <- ncol(mf[["x"]])
  df <- nt_obs - (n + t) * r - k
  if (additive_effects == "xs+time") {
    df <- df - n - t
  } else if (additive_effects == "xs") {
    df <- df - n
  } else if (additive_effects == "time") {
    df <- df - t
  }
  df
}


# em pca algorithm (see Bai, Liao, and Yang (2015))
em_pca <- function(gamma, r, observed) {
  gamma_hat <- gamma
  missing <- !observed
  gamma_hat[missing] <- 0.0
  theta0 <- numeric(sum(missing))
  for (iter in seq.int(1000L)) {
    theta <- principal_components(gamma_hat, r)[["theta"]][missing]
    gamma_hat[missing] <- theta
    crit <- sum((theta - theta0)^2) / sum(theta0^2)
    if (crit < 1.0e-08) break
    theta0 <- theta
  }
  gamma_hat
}


# matrix completion
matrix_completion <- function(gamma, r, observed, nu) {
  if (nu > 0.0) {
    n <- nrow(gamma)
    t <- ncol(gamma)
    delta <- matrix(NA_integer_, n, t)
    delta[observed] <- 1L
    delta[!observed] <- 0L
    fit <- suppressWarnings(softImpute(
      gamma,
      rank.max = r, lambda = nu, type = "svd"
    ))
    gamma_hat <- complete(gamma, fit)
    pca <- principal_components(gamma_hat, r)
    gamma_tilde <- two_least_squares(gamma, delta, t(pca[["lambda"]]))
  } else {
    gamma_tilde <- em_pca(gamma, r, observed)
  }
  gamma_tilde[observed] <- gamma[observed]
  gamma_tilde
}


# model frame
model_frame <- function(formula, data, additive_effects) {
  y <- data[["pd"]][[all.vars(formula)[[1L]]]]
  x <- model.matrix(formula, data[["pd"]])[, -1L, drop = FALSE]
  lt <- data[["lookup_table"]]
  if (additive_effects == "gm") {
    y <- y - mean(y)
    x <- t(t(x) - colMeans(x))
  } else if (additive_effects == "xs") {
    y <- as.vector(within_ow(y, lt[[1L]]))
    x <- apply(x, 2L, FUN = within_ow, lt = lt[[1L]])
  } else if (additive_effects == "time") {
    y <- as.vector(within_ow(y, lt[[2L]]))
    x <- apply(x, 2L, FUN = within_ow, lt = lt[[2L]])
  } else if (additive_effects == "xs+time") {
    y <- as.vector(within_tw(y, lt, 1.0e-08))
    x <- apply(x, 2L, FUN = within_tw, lt = lt, tol = 1.0e-08)
  }
  pdim <- c(data[["sample_size"]][[2L]], data[["sample_size"]][[3L]])
  mf <- list(y = y, x = x, pdim = pdim, pids = data[["pids"]], lookup_table = lt)
  if (inherits(data, "pd_unbal")) {
    mf <- c(mf, list(observed = data[["observed"]]))
  }
  mf
}


# least squares fit
ls_fit <- function(beta_start, mf, r, nu, trace) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  xs_id <- mf[["pids"]][[1L]]
  time_id <- mf[["pids"]][[2L]]
  if (is.null(mf[["observed"]])) {
    opt <- optim(
      beta_start, f_ls_bal, g_ls_bal,
      mf = mf, r = r, method = "BFGS",
      control = list(maxit = 500L, trace = trace)
    )
    beta_hat <- opt[["par"]]
    pfm <- mf[["y"]] - as.vector(mf[["x"]] %*% beta_hat)
    gamma <- matrix(pfm, n, t)
    pca <- principal_components(gamma, r)
    u_hat <- as.vector(gamma - pca[["theta"]])
  } else {
    pfm <- mf[["y"]] - as.vector(mf[["x"]] %*% beta_start)
    observed <- mf[["observed"]]
    gamma <- matrix(NA_real_, n, t)
    gamma[observed] <- pfm
    opt <- optim(
      beta_start, f_ls_unbal, g_ls_unbal,
      mf = mf, r = r, nu = nu, method = "BFGS",
      control = list(maxit = 500L, trace = trace)
    )
    beta_hat <- opt[["par"]]
    pfm <- mf[["y"]] - as.vector(mf[["x"]] %*% beta_hat)
    gamma[observed] <- pfm
    gamma <- matrix_completion(gamma, r, observed, nu)
    pca <- principal_components(gamma, r)
    u_hat <- as.vector(gamma - pca[["theta"]])[observed]
  }
  names(beta_hat) <- colnames(mf[["x"]])
  lambda <- pca[["lambda"]]
  f <- pca[["f"]]
  y_hat <- mf[["y"]] - u_hat
  xt_11 <- apply(
    mf[["x"]], 2L,
    FUN = weighted_within_tw, tL = t(lambda), tF = t(f),
    pids = mf[["pids"]], lt = mf[["lookup_table"]],
    tol = 1.0e-08
  )
  W <- crossprod(xt_11)
  Omega <- crossprod(xt_11 * u_hat)
  opt_info <- list(
    value = opt[["value"]],
    counts = opt[["counts"]],
    convergence = opt[["convergence"]],
    message = opt[["message"]]
  )
  list(
    coefficients = beta_hat,
    lambda = lambda,
    f = f,
    r = r,
    fitted = y_hat,
    residuals = u_hat,
    pfm = pfm,
    W = W,
    Omega = Omega,
    beta_start = beta_start,
    opt_info = opt_info,
    nu = nu
  )
}


# Perry-Gavish-Donoho threshold for DPA
pgd_threshold <- function(mu, theta) {
  m <- mean((mu[-1L] - mu[[1L]])^(-1))
  v <- theta * m - (1.0 - theta) / mu[[1L]]
  D <- mu[[1L]] * m * v
  l <- 1.0 / D
  d1_m <- mean((mu[-1L] - mu[[1L]])^(-2))
  d1_v <- theta * d1_m + (1.0 - theta) / mu[[1L]]^2
  d1_D <- m * v + mu[[1L]] * (m * d1_v + d1_m * v)
  c_l_sq <- v / d1_D * l
  c_r_sq <- m / d1_D * l
  4 * l * c_l_sq * c_r_sq
}


# plug-in approach  for soft imputation
plugin_nu <- function(mf, beta_start, r_max, n_iter, n_sim) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  pfm <- mf[["y"]] - as.vector(mf[["x"]] %*% beta_start)
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- pfm
  sigma_hat <- sd(as.vector(gamma), na.rm = TRUE)
  z_ast <- sapply(seq.int(n_sim), function(r, n, t, observed, sigma_hat) {
    z <- matrix(rnorm(n * t, 0.0, sigma_hat), n, t)
    z[!observed] <- 0.0
    norm(z, "2")
  }, n = n, t = t, observed = observed, sigma_hat = sigma_hat)
  nu <- 1.1 * quantile(z_ast, 0.95)
  fit <- NULL
  for (k in seq.int(n_iter)) {
    nu_old <- nu
    fit <- softImpute(gamma, rank.max = r_max, lambda = nu, type = "svd", warm.start = fit)
    gamma_hat <- tcrossprod(fit[["u"]], fit[["v"]] * fit[["d"]])
    e_hat <- gamma - gamma_hat
    sigma_hat <- sqrt(mean(e_hat^2, na.rm = TRUE))
    z_ast <- sapply(seq.int(n_sim), function(r, n, t, observed, sigma_hat) {
      z <- matrix(rnorm(n * t, 0.0, sigma_hat), n, t)
      z[!observed] <- 0.0
      norm(z, "2")
    }, n = n, t = t, observed = observed, sigma_hat = sigma_hat)
    nu <- 1.1 * quantile(z_ast, 0.95)
    if (abs(nu - nu_old) / nu_old < 0.01) break
  }
  names(nu) <- NULL
  nu
}


# estimate leading principal components
principal_components <- function(gamma, r) {
  n <- nrow(gamma)
  t <- ncol(gamma)
  if (n > t) {
    ev_lst <- eigen(crossprod(gamma) / n / t, symmetric = TRUE)
    f <- ev_lst[["vectors"]][, seq.int(r), drop = FALSE] * sqrt(t)
    lambda <- gamma %*% f / t
  } else {
    ev_lst <- eigen(tcrossprod(gamma) / n / t, symmetric = TRUE)
    lambda <- ev_lst[["vectors"]][, seq.int(r), drop = FALSE] * sqrt(n)
    f <- crossprod(gamma, lambda / n)
  }
  theta <- tcrossprod(lambda, f)
  list(f = f, lambda = lambda, theta = theta)
}


# compute starting values based on nnm estimators
starting_values <- function(mf) {
  beta_start <- coef(.lm.fit(mf[["x"]], mf[["y"]]))
  if (is.null(mf[["observed"]])) {
    opt <- optim(
      beta_start, f_nmm_bal, g_nmm_bal,
      mf = mf, method = "BFGS", control = list(maxit = 500L)
    )
  } else {
    opt <- optim(
      beta_start, f_nmm_unbal, g_nmm_unbal,
      mf = mf, method = "BFGS", control = list(maxit = 500L)
    )
  }
  opt[["par"]]
}

# unload
.onUnload <- function(libpath) library.dynam.unload("InteractiveEffects", libpath)


## balanced panel


# profile least squares objective function of Moon and Weidner (2015, 2017)
f_ls_bal <- function(beta, mf, r) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  gamma <- matrix(mf[["y"]] - as.vector(mf[["x"]] %*% beta), n, t)
  if (n > t) {
    mu <- eigen(
      crossprod(gamma) / n / t,
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
    mu <- mu[seq.int(r + 1L, t)]
  } else {
    mu <- eigen(
      tcrossprod(gamma) / n / t,
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
    mu <- mu[seq.int(r + 1L, n)]
  }
  sum(mu)
}


# gradient of the profile least squares objective function of Moon and Weidner (2015, 2017)
g_ls_bal <- function(beta, mf, r) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  gamma <- matrix(mf[["y"]] - as.vector(mf[["x"]] %*% beta), n, t)
  u <- as.vector(gamma - principal_components(gamma, r)[["theta"]])
  -2.0 * colSums(mf[["x"]] * u) / n / t
}


# objective function of nuclear norm minimizing estimator by Moon and Weidner (2025)
f_nmm_bal <- function(beta, mf) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  gamma <- matrix(mf[["y"]] - as.vector(mf[["x"]] %*% beta), n, t)
  if (n > t) {
    mu <- eigen(
      crossprod(gamma),
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
  } else {
    mu <- eigen(
      tcrossprod(gamma),
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
  }
  sigma <- sqrt(mu[mu > 0])
  sum(sigma) / n / t
}


# gradient of nuclear norm minimizing estimator by Moon and Weidner (2025)
g_nmm_bal <- function(beta, mf) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  gamma <- matrix(mf[["y"]] - as.vector(mf[["x"]] %*% beta), n, t)
  svd_lst <- svd(gamma)
  d_w <- as.vector(tcrossprod(svd_lst[["u"]], svd_lst[["v"]]))
  -colSums(mf[["x"]] * d_w) / n / t
}


## unbalanced panel


# profile least squares objective function of Moon and Weidner (2015, 2017)
f_ls_unbal <- function(beta, mf, r, nu) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- mf[["y"]] - as.vector(mf[["x"]] %*% beta)
  gamma <- matrix_completion(gamma, r, observed, nu)
  if (n > t) {
    mu <- eigen(
      crossprod(gamma) / n / t,
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
    mu <- mu[seq.int(r + 1L, t)]
  } else {
    mu <- eigen(
      tcrossprod(gamma) / n / t,
      symmetric = TRUE,
      only.values = TRUE
    )[["values"]]
    mu <- mu[seq.int(r + 1L, n)]
  }
  sum(mu)
}


# gradient of the profile least squares objective function of Moon and Weidner (2015, 2017)
g_ls_unbal <- function(beta, mf, r, nu) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- mf[["y"]] - as.vector(mf[["x"]] %*% beta)
  gamma <- matrix_completion(gamma, r, observed, nu)
  u <- as.vector(gamma - principal_components(gamma, r)[["theta"]])[observed]
  -2.0 * colSums(mf[["x"]] * u) / n / t
}


# objective function of nuclear norm minimizing estimator by Moon and Weidner (2025)
f_nmm_unbal <- function(beta, mf) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- mf[["y"]] - as.vector(mf[["x"]] %*% beta)
  gamma[!observed] <- 0.0
  if (n > t) {
    mu <- eigen(
      crossprod(gamma),
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
  } else {
    mu <- eigen(
      tcrossprod(gamma),
      symmetric = TRUE, only.values = TRUE
    )[["values"]]
  }
  sigma <- sqrt(mu[mu > 0.0])
  sum(sigma) / n / t
}


# gradient of nuclear norm minimizing estimator by Moon and Weidner (2025)
g_nmm_unbal <- function(beta, mf) {
  n <- mf[["pdim"]][[1L]]
  t <- mf[["pdim"]][[2L]]
  observed <- mf[["observed"]]
  gamma <- matrix(NA_real_, n, t)
  gamma[observed] <- mf[["y"]] - as.vector(mf[["x"]] %*% beta)
  gamma[!observed] <- 0.0
  svd_lst <- svd(gamma)
  d_w <- as.vector(tcrossprod(svd_lst[["u"]], svd_lst[["v"]]))[observed]
  -colSums(mf[["x"]] * d_w) / n / t
}
